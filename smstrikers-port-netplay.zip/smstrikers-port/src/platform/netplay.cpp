// See include/port/netplay.h.

#include "port/netplay.h"

#if defined(PORT_USE_AURORA) && (defined(__ANDROID__) || defined(__linux__) || defined(__APPLE__))

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "dolphin/pad.h"

namespace
{

constexpr uint8_t kMagic = 0xA7;
constexpr uint8_t kProto = 1;

enum PacketType : uint8_t
{
    kHello = 1,   // joiner -> host: [magic, type, proto]
    kStart = 2,   // host -> joiner: [magic, type, delay]
    kInput = 3,   // both ways, see send_input()
    kBye = 4,
};

enum Mode
{
    kOff,
    kHost,
    kJoin,
};

constexpr int kRing = 256;       // frames of history; far more than a session ever has in flight
constexpr int kMaxSend = 24;     // inputs per packet. Each one rides in several packets, which is
                                 // how a lost packet costs nothing
constexpr int kCsumSlots = 16;
constexpr long kCsumEvery = 50;   // frames, one second at the game's 50 Hz

// What crosses the network of a controller: the same fields the game reads, 8 bytes.
struct Pad8
{
    uint16_t button;
    int8_t sx, sy, cx, cy;
    uint8_t tl, tr;
};

struct Csum
{
    long frame = -1;
    uint32_t value = 0;
};

Mode s_mode = kOff;
bool s_modeRead = false;
bool s_active = false;

int s_fd = -1;
sockaddr_in s_peer;
bool s_havePeer = false;

int s_delay = 3;
int s_timeoutMs = 120 * 1000;

PortNetPumpFn s_pump = nullptr;
PortNetQuitFn s_quit = nullptr;

Pad8 s_local[kRing];
long s_localTag[kRing];
Pad8 s_remote[kRing];
long s_remoteTag[kRing];

long s_localNewest = -1;   // newest frame whose local input is known
long s_remoteNext = 0;     // first frame we do not have from the peer: what we acknowledge
long s_peerAck = 0;        // first frame the peer has not acknowledged of ours
long s_base = -1;          // the game's frame number when the session began
long s_lastFrame = -1;
bool s_peerGone = false;

Csum s_localCsum[kCsumSlots];
Csum s_remoteCsum[kCsumSlots];
Csum s_lastSent;           // newest checksum of ours, repeated in every packet
long s_desyncReported = -1;
bool s_desynced = false;

// Clock

int64_t now_ms()
{
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

// Configuration. strikers.ini keys arrive as STRIKERS_<KEY> environment variables.

const char* cfg(const char* name)
{
    const char* v = std::getenv(name);
    return (v != nullptr && *v != '\0') ? v : nullptr;
}

bool ieq(const char* a, const char* b)
{
    for (; *a != '\0' && *b != '\0'; a++, b++)
    {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca = (char)(ca - 'A' + 'a');
        if (cb >= 'A' && cb <= 'Z') cb = (char)(cb - 'A' + 'a');
        if (ca != cb)
            return false;
    }
    return *a == *b;
}

int cfg_int(const char* name, int fallback, int lo, int hi)
{
    const char* v = cfg(name);
    if (v == nullptr)
        return fallback;
    const long n = std::strtol(v, nullptr, 10);
    return (int)(n < lo ? lo : (n > hi ? hi : n));
}

Mode read_mode()
{
    if (s_modeRead)
        return s_mode;
    s_modeRead = true;
    const char* v = cfg("STRIKERS_NET_MODE");
    if (v == nullptr)
        s_mode = kOff;
    else if (ieq(v, "host"))
        s_mode = kHost;
    else if (ieq(v, "join") || ieq(v, "client"))
        s_mode = kJoin;
    else
    {
        if (!ieq(v, "off") && !ieq(v, "0"))
            std::fprintf(stderr, "[net] net_mode = \"%s\" is not off, host or join; netplay is off\n", v);
        s_mode = kOff;
    }
    return s_mode;
}

// Wire format. Little-endian, written byte by byte so nothing depends on the host.

void put32(uint8_t* p, uint32_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

uint32_t get32(const uint8_t* p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

void put_pad(uint8_t* p, const Pad8& s)
{
    p[0] = (uint8_t)s.button;
    p[1] = (uint8_t)(s.button >> 8);
    p[2] = (uint8_t)s.sx;
    p[3] = (uint8_t)s.sy;
    p[4] = (uint8_t)s.cx;
    p[5] = (uint8_t)s.cy;
    p[6] = s.tl;
    p[7] = s.tr;
}

Pad8 get_pad(const uint8_t* p)
{
    Pad8 s;
    s.button = (uint16_t)(p[0] | (p[1] << 8));
    s.sx = (int8_t)p[2];
    s.sy = (int8_t)p[3];
    s.cx = (int8_t)p[4];
    s.cy = (int8_t)p[5];
    s.tl = p[6];
    s.tr = p[7];
    return s;
}

PADStatus to_status(const Pad8& s)
{
    PADStatus st;
    std::memset(&st, 0, sizeof st);
    st.button = s.button;
    st.stickX = s.sx;
    st.stickY = s.sy;
    st.substickX = s.cx;
    st.substickY = s.cy;
    st.triggerLeft = s.tl;
    st.triggerRight = s.tr;
    st.err = PAD_ERR_NONE;
    return st;
}

// Frame storage

bool have_remote(long f) { return f >= 0 && s_remoteTag[f % kRing] == f; }
bool have_local(long f) { return f >= 0 && s_localTag[f % kRing] == f; }

void set_local(long f, const Pad8& s)
{
    s_local[f % kRing] = s;
    s_localTag[f % kRing] = f;
}

void set_remote(long f, const Pad8& s)
{
    s_remote[f % kRing] = s;
    s_remoteTag[f % kRing] = f;
}

// Socket

bool send_raw(const uint8_t* data, size_t n)
{
    if (s_fd < 0 || !s_havePeer)
        return false;
    const ssize_t r = ::sendto(s_fd, data, n, 0, (const sockaddr*)&s_peer, sizeof s_peer);
    return r == (ssize_t)n;
}

void send_control(uint8_t type, uint8_t arg)
{
    const uint8_t p[3] = {kMagic, type, arg};
    send_raw(p, sizeof p);
}

// [magic, kInput, ack u32, first u32, count u8, count * 8 bytes, csumFrame u32, csumValue u32]
void send_input()
{
    uint8_t buf[2 + 4 + 4 + 1 + 8 * kMaxSend + 8];
    size_t n = 0;
    buf[n++] = kMagic;
    buf[n++] = kInput;
    put32(buf + n, (uint32_t)s_remoteNext);
    n += 4;

    long first = s_peerAck;
    if (first < s_localNewest - (kMaxSend - 1))
        first = s_localNewest - (kMaxSend - 1);
    if (first < 0)
        first = 0;
    int count = 0;
    for (long f = first; f <= s_localNewest && count < kMaxSend; f++)
        if (have_local(f))
            count++;
        else
            break;

    put32(buf + n, (uint32_t)first);
    n += 4;
    buf[n++] = (uint8_t)count;
    for (int i = 0; i < count; i++)
    {
        put_pad(buf + n, s_local[(first + i) % kRing]);
        n += 8;
    }

    put32(buf + n, s_lastSent.frame < 0 ? 0xFFFFFFFFu : (uint32_t)s_lastSent.frame);
    n += 4;
    put32(buf + n, s_lastSent.value);
    n += 4;
    send_raw(buf, n);
}

// Checksums

void check_csum(long frame)
{
    const int slot = (int)((frame / kCsumEvery) % kCsumSlots);
    const Csum& l = s_localCsum[slot];
    const Csum& r = s_remoteCsum[slot];
    if (l.frame != frame || r.frame != frame || l.value == r.value)
        return;
    s_desynced = true;
    if (s_desyncReported != frame)
    {
        s_desyncReported = frame;
        std::fprintf(stderr, "[net] DESYNC at frame %ld: local %08x, peer %08x\n", frame,
                     (unsigned)l.value, (unsigned)r.value);
    }
}

void note_remote_csum(long frame, uint32_t value)
{
    if (frame < 0 || (frame % kCsumEvery) != 0)
        return;
    const int slot = (int)((frame / kCsumEvery) % kCsumSlots);
    if (s_remoteCsum[slot].frame == frame)
        return;
    s_remoteCsum[slot].frame = frame;
    s_remoteCsum[slot].value = value;
    check_csum(frame);
}

// One packet from the peer.

bool from_peer(const sockaddr_in& from)
{
    return s_havePeer && from.sin_addr.s_addr == s_peer.sin_addr.s_addr &&
           from.sin_port == s_peer.sin_port;
}

// Returns the packet type that was handled, or 0 for nothing / ignored.
int handle_packet(const uint8_t* p, size_t n, const sockaddr_in& from)
{
    if (n < 3 || p[0] != kMagic)
        return 0;
    const uint8_t type = p[1];

    if (type == kHello)
    {
        if (read_mode() != kHost || p[2] != kProto)
            return 0;
        if (!s_havePeer)
        {
            s_peer = from;
            s_havePeer = true;
            char ip[INET_ADDRSTRLEN] = "?";
            inet_ntop(AF_INET, &from.sin_addr, ip, sizeof ip);
            std::fprintf(stderr, "[net] %s:%u joined\n", ip, (unsigned)ntohs(from.sin_port));
        }
        else if (!from_peer(from))
            return 0;
        // Said again to every HELLO: the first START may have been lost.
        send_control(kStart, (uint8_t)s_delay);
        return kHello;
    }

    if (!from_peer(from))
        return 0;

    if (type == kStart)
    {
        if (read_mode() == kJoin && p[2] >= 1 && p[2] <= 8)
            s_delay = p[2];
        return kStart;
    }

    if (type == kBye)
    {
        s_peerGone = true;
        return kBye;
    }

    if (type == kInput)
    {
        if (n < 2 + 4 + 4 + 1)
            return 0;
        const uint8_t* q = p + 2;
        const long ack = (long)get32(q);
        q += 4;
        const long first = (long)get32(q);
        q += 4;
        const int count = *q++;
        if (n < 2 + 4 + 4 + 1 + (size_t)count * 8 + 8)
            return 0;

        for (int i = 0; i < count; i++, q += 8)
        {
            const long f = first + i;
            // Only what can be next: a stale resend or a wild number is ignored.
            if (f < s_remoteNext || f >= s_remoteNext + kRing / 2)
                continue;
            if (!have_remote(f))
                set_remote(f, get_pad(q));
        }
        const uint32_t csumFrame = get32(q);
        q += 4;
        const uint32_t csumValue = get32(q);

        if (ack > s_peerAck)
            s_peerAck = ack;
        while (have_remote(s_remoteNext))
            s_remoteNext++;
        if (csumFrame != 0xFFFFFFFFu)
            note_remote_csum((long)csumFrame, csumValue);
        return kInput;
    }
    return 0;
}

// Reads everything waiting. Returns the number of packets that were ours.
int drain()
{
    int handled = 0;
    for (;;)
    {
        uint8_t buf[512];
        sockaddr_in from;
        socklen_t len = sizeof from;
        const ssize_t n = ::recvfrom(s_fd, buf, sizeof buf, 0, (sockaddr*)&from, &len);
        if (n < 0)
            break;   // EAGAIN: nothing more
        if (handle_packet(buf, (size_t)n, from) != 0)
            handled++;
    }
    return handled;
}

void wait_readable(int ms)
{
    pollfd pfd;
    pfd.fd = s_fd;
    pfd.events = POLLIN;
    pfd.revents = 0;
    ::poll(&pfd, 1, ms);
}

void log_local_addresses(int port)
{
    ifaddrs* list = nullptr;
    if (::getifaddrs(&list) != 0 || list == nullptr)
        return;
    for (ifaddrs* a = list; a != nullptr; a = a->ifa_next)
    {
        if (a->ifa_addr == nullptr || a->ifa_addr->sa_family != AF_INET)
            continue;
        char ip[INET_ADDRSTRLEN];
        const sockaddr_in* sin = (const sockaddr_in*)a->ifa_addr;
        if (inet_ntop(AF_INET, &sin->sin_addr, ip, sizeof ip) == nullptr)
            continue;
        if (std::strncmp(ip, "127.", 4) == 0)
            continue;
        std::fprintf(stderr, "[net] host address: %s:%d (%s)\n", ip, port, a->ifa_name);
    }
    ::freeifaddrs(list);
}

void close_socket()
{
    if (s_fd >= 0)
    {
        ::close(s_fd);
        s_fd = -1;
    }
}

void clear_overrides()
{
    for (u32 port = 0; port < PAD_CHANMAX; port++)
        PADClearOverrideStatus(port);
}

// Everything that has to be true for the first frame, identical on both devices.
void begin_session()
{
    for (int i = 0; i < kRing; i++)
    {
        s_localTag[i] = -1;
        s_remoteTag[i] = -1;
    }
    const Pad8 neutral = {};
    // The first `delay` frames have no input from anybody: that is what the delay is. Both sides
    // fill them the same way and neither sends them.
    for (long f = 0; f < s_delay; f++)
    {
        set_local(f, neutral);
        set_remote(f, neutral);
    }
    s_localNewest = s_delay - 1;
    s_remoteNext = s_delay;
    s_peerAck = s_delay;
    s_base = -1;
    s_lastFrame = -1;
    s_active = true;
    std::fprintf(stderr, "[net] session started: %s, input delay %d frames\n",
                 read_mode() == kHost ? "host (port 0)" : "joiner (port 1)", s_delay);
}

}   // namespace

extern "C" int PortNetRequested(void) { return read_mode() != kOff ? 1 : 0; }

extern "C" int PortNetActive(void) { return s_active ? 1 : 0; }

extern "C" void PortNetPreInit(void)
{
    if (read_mode() == kOff)
        return;

    // The same four settings the port's own deterministic runs use. They override the ini on
    // purpose: a session where the two devices differ on any of them is a session that desyncs.
    //   FIXED_DT 20  the game's clock advances 20 ms per frame whatever the host clock says
    //   SEED         both devices roll the same dice
    //   FPS_LIMIT 50 so that 20 ms per frame is also 20 ms of real time
    //   VSYNC 0      or a 60 Hz panel would run the game 20 % fast
    setenv("STRIKERS_FIXED_DT", "20", 1);
    setenv("STRIKERS_FPS_LIMIT", "50", 1);
    setenv("STRIKERS_VSYNC", "0", 1);
    const char* seed = cfg("STRIKERS_NET_SEED");
    setenv("STRIKERS_SEED", seed != nullptr ? seed : "19930721", 1);

    std::fprintf(stderr, "[net] net_mode = %s: clock, seed, 50 fps limit and vsync pinned\n",
                 read_mode() == kHost ? "host" : "join");
}

extern "C" int PortNetStart(PortNetPumpFn pump, PortNetQuitFn quit)
{
    if (read_mode() == kOff)
        return 0;

    s_pump = pump;
    s_quit = quit;
    const int port = cfg_int("STRIKERS_NET_PORT", 7777, 1024, 65535);
    s_timeoutMs = cfg_int("STRIKERS_NET_TIMEOUT", 120, 5, 600) * 1000;
    if (read_mode() == kHost)
        s_delay = cfg_int("STRIKERS_NET_DELAY", 3, 1, 8);

    s_fd = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (s_fd < 0)
    {
        std::fprintf(stderr, "[net] no socket (%s); playing offline\n", std::strerror(errno));
        return 0;
    }
    ::fcntl(s_fd, F_SETFL, ::fcntl(s_fd, F_GETFL, 0) | O_NONBLOCK);
    int yes = 1;
    ::setsockopt(s_fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

    sockaddr_in me;
    std::memset(&me, 0, sizeof me);
    me.sin_family = AF_INET;
    me.sin_addr.s_addr = htonl(INADDR_ANY);
    me.sin_port = htons(read_mode() == kHost ? (uint16_t)port : 0);
    if (::bind(s_fd, (const sockaddr*)&me, sizeof me) != 0)
    {
        std::fprintf(stderr, "[net] cannot bind UDP %d (%s); playing offline\n", port,
                     std::strerror(errno));
        close_socket();
        return 0;
    }

    if (read_mode() == kJoin)
    {
        const char* host = cfg("STRIKERS_NET_HOST");
        std::memset(&s_peer, 0, sizeof s_peer);
        s_peer.sin_family = AF_INET;
        s_peer.sin_port = htons((uint16_t)port);
        if (host == nullptr || inet_pton(AF_INET, host, &s_peer.sin_addr) != 1)
        {
            std::fprintf(stderr,
                         "[net] net_host = \"%s\" is not an IPv4 address; playing offline\n",
                         host != nullptr ? host : "");
            close_socket();
            return 0;
        }
        s_havePeer = true;
        std::fprintf(stderr, "[net] joining %s:%d\n", host, port);
    }
    else
    {
        std::fprintf(stderr, "[net] waiting for the other device on UDP %d\n", port);
        log_local_addresses(port);
    }

    const int64_t t0 = now_ms();
    int64_t lastHello = 0, lastPump = 0;
    bool started = false;
    while (!started)
    {
        const int64_t t = now_ms();
        if (t - t0 > s_timeoutMs)
        {
            std::fprintf(stderr, "[net] nobody answered in %d s; playing offline\n",
                         s_timeoutMs / 1000);
            close_socket();
            return 0;
        }
        if (s_quit != nullptr && s_quit())
        {
            close_socket();
            return 0;
        }
        if (s_pump != nullptr && t - lastPump >= 100)
        {
            s_pump();
            lastPump = t;
        }

        if (read_mode() == kJoin && t - lastHello >= 250)
        {
            send_control(kHello, kProto);
            lastHello = t;
        }

        wait_readable(20);
        for (;;)
        {
            uint8_t buf[512];
            sockaddr_in from;
            socklen_t len = sizeof from;
            const ssize_t n = ::recvfrom(s_fd, buf, sizeof buf, 0, (sockaddr*)&from, &len);
            if (n < 0)
                break;
            const int what = handle_packet(buf, (size_t)n, from);
            // The host is ready when it has answered a HELLO; the joiner when it hears START. An
            // input packet is START too, for a joiner whose START was lost.
            if (read_mode() == kHost && what == kHello)
                started = true;
            if (read_mode() == kJoin && (what == kStart || what == kInput))
                started = true;
        }
    }

    // The joiner's delay came from START and is known only now.
    begin_session();
    return 1;
}

extern "C" void PortNetFrame(unsigned long frameU, unsigned int stateChecksum)
{
    if (!s_active)
        return;

    const long frame = (long)frameU;
    if (s_base < 0)
        s_base = frame;
    const long n = frame - s_base;

    // The loop can come back for the same frame (a minimised window skips the draw); what was set
    // for it still stands.
    if (n == s_lastFrame)
        return;
    s_lastFrame = n;

    // 1. The local controller, read the way the game is about to read it. The overrides from the
    //    last frame are lifted first so that what comes back is the hardware and nothing else.
    clear_overrides();
    PADStatus raw[PAD_CHANMAX];
    PADRead(raw);
    Pad8 mine = {};
    if (raw[0].err == PAD_ERR_NONE)
    {
        mine.button = (uint16_t)raw[0].button;
        mine.sx = raw[0].stickX;
        mine.sy = raw[0].stickY;
        mine.cx = raw[0].substickX;
        mine.cy = raw[0].substickY;
        mine.tl = raw[0].triggerLeft;
        mine.tr = raw[0].triggerRight;
    }
    // It acts `delay` frames from now, which is the time the network has to deliver it.
    set_local(n + s_delay, mine);
    s_localNewest = n + s_delay;

    // 2. The digest, taken before frame n is simulated, so both devices take it at the same point.
    if ((n % kCsumEvery) == 0)
    {
        const int slot = (int)((n / kCsumEvery) % kCsumSlots);
        s_localCsum[slot].frame = n;
        s_localCsum[slot].value = stateChecksum;
        s_lastSent = s_localCsum[slot];
        check_csum(n);
    }

    send_input();

    // 3. Frame n cannot run without the peer's controller for frame n. With the delay in place it
    //    left the peer `delay` frames ago, so on a healthy network this loop never loops.
    const int64_t t0 = now_ms();
    int64_t lastSend = t0, lastPump = t0;
    drain();
    while (!have_remote(n) && !s_peerGone)
    {
        wait_readable(4);
        drain();
        if (have_remote(n))
            break;

        const int64_t t = now_ms();
        if (t - lastSend >= 40)
        {
            send_input();   // the packet that would have fixed this may be the one that was lost
            lastSend = t;
        }
        if (s_pump != nullptr && t - lastPump >= 100)
        {
            s_pump();
            lastPump = t;
        }
        if ((s_quit != nullptr && s_quit()) || t - t0 > s_timeoutMs / 4)
        {
            s_peerGone = true;
            std::fprintf(stderr, "[net] no input from the other device for %lld ms\n",
                         (long long)(t - t0));
        }
    }

    if (s_peerGone && !have_remote(n))
    {
        // The match goes on without the other device, on this one's own controllers.
        std::fprintf(stderr, "[net] session over at frame %ld; continuing offline\n", n);
        s_active = false;
        clear_overrides();
        close_socket();
        return;
    }

    // 4. Both controllers for frame n are known, on both devices. The host is port 0.
    const bool host = read_mode() == kHost;
    const Pad8& p0 = host ? s_local[n % kRing] : s_remote[n % kRing];
    const Pad8& p1 = host ? s_remote[n % kRing] : s_local[n % kRing];
    PADStatus st0 = to_status(p0);
    PADStatus st1 = to_status(p1);
    PADSetOverrideStatus(0, &st0);
    PADSetOverrideStatus(1, &st1);

    PADStatus absent;
    std::memset(&absent, 0, sizeof absent);
    absent.err = PAD_ERR_NO_CONTROLLER;
    PADSetOverrideStatus(2, &absent);
    PADSetOverrideStatus(3, &absent);
}

extern "C" void PortNetShutdown(void)
{
    if (s_fd >= 0 && s_havePeer)
        for (int i = 0; i < 3; i++)
            send_control(kBye, 0);
    clear_overrides();
    close_socket();
    s_active = false;
}

#else   // no sockets, or not the Aurora build

extern "C" int PortNetRequested(void) { return 0; }
extern "C" void PortNetPreInit(void) {}
extern "C" int PortNetStart(PortNetPumpFn, PortNetQuitFn) { return 0; }
extern "C" int PortNetActive(void) { return 0; }
extern "C" void PortNetFrame(unsigned long, unsigned int) {}
extern "C" void PortNetShutdown(void) {}

#endif
